import random

# Step 1: Generate a dynamic list of 400 workers
workers = [{"id": i, "name": f"Worker-{i}", "gender": random.choice(["Male", "Female"]), 
            "salary": random.randint(5000, 30000)} for i in range(1, 401)]

# Step 2: Generate payment slips
def generate_payment_slip(worker):
    try:
        level = "Unknown"  # Default level
        salary = worker["salary"]
        gender = worker["gender"]

        # Conditional statements
        if 10000 < salary < 20000:
            level = "A1"
        if 7500 < salary < 30000 and gender == "Female":
            level = "A5-F"

        # Payment slip
        payment_slip = (f"Payment Slip for {worker['name']}:\n"
                        f"Worker ID: {worker['id']}\n"
                        f"Gender: {gender}\n"
                        f"Salary: ${salary}\n"
                        f"Employee Level: {level}\n")
        return payment_slip
    except Exception as e:
        return f"Error generating slip for {worker['name']}: {str(e)}"

# Step 3: Create payment slips for all workers
payment_slips = []
for worker in workers:
    payment_slip = generate_payment_slip(worker)
    payment_slips.append(payment_slip)

# Display or save payment slips
for slip in payment_slips[:10]:  # Display the first 10 slips for preview
    print(slip)
    print("-" * 50)

# Save to file for submission
with open("payment_slips.txt", "w") as file:
    file.writelines("\n".join(payment_slips))
