
# Highridge Construction Company Payment Slips

This repository contains Python and R scripts for generating payment slips for Highridge Construction Company workers.

## Files
- **payment_slips.py**: Python script for generating payment slips.
- **payment_slips.R**: R script for the same functionality.
- **README.md**: Instructions for running the scripts.

## Requirements
- **Python**: Python 3.x and the `random` module (standard library).
- **R**: R 4.x.

## How to Use
1. Run the Python script:
   ```bash
   python payment_slips.py
   ```
   This will create a `payment_slips.txt` file with all the slips.

2. Run the R script:
   ```R
   source("payment_slips.R")
   ```
   This will also generate the `payment_slips.txt` file.

## Notes
- Both scripts include exception handling to prevent errors.
- Ensure `payment_slips.txt` is writable.
