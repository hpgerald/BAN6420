# Step 1: Generate a dynamic list of 400 workers
set.seed(123)
workers <- data.frame(
  id = 1:400,
  name = paste0("Worker-", 1:400),
  gender = sample(c("Male", "Female"), 400, replace = TRUE),
  salary = sample(5000:30000, 400, replace = TRUE)
)

# Step 2: Generate payment slips
generate_payment_slip <- function(worker) {
  tryCatch({
    level <- "Unknown"
    
    # Conditional statements
    if (worker$salary > 10000 & worker$salary < 20000) {
      level <- "A1"
    }
    if (worker$salary > 7500 & worker$salary < 30000 & worker$gender == "Female") {
      level <- "A5-F"
    }
    
    # Payment slip
    payment_slip <- paste0(
      "Payment Slip for ", worker$name, ":\n",
      "Worker ID: ", worker$id, "\n",
      "Gender: ", worker$gender, "\n",
      "Salary: $", worker$salary, "\n",
      "Employee Level: ", level, "\n"
    )
    return(payment_slip)
  }, error = function(e) {
    return(paste0("Error generating slip for ", worker$name, ": ", e$message))
  })
}

# Step 3: Create payment slips for all workers
payment_slips <- apply(workers, 1, function(row) generate_payment_slip(as.list(row)))

# Display or save payment slips
cat(paste(payment_slips[1:10], collapse = "\n--------------------\n")) # Display first 10
writeLines(payment_slips, "payment_slips.txt")

